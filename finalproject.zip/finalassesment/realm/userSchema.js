export default {
	name: "User",
	properties: {
		type: "string",
		name: "string",
		username: "string",
		password: "string",
		//favourites: "Movie[]",
		//status: "string",
	}
};