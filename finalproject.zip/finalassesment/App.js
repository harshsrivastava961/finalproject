import React from 'react';
import AppRouter from './navigation/nav';
import 'react-native-gesture-handler';

const App=()=>{
  return(
      <AppRouter />
    )
}

export default App;