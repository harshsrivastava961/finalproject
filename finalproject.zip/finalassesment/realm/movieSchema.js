export default {
	name: "Movie",
	properties: {
		id: "int",
		title: "string",
		genre: "string",
		movieURL: "string",
		plotSummary: "string",
	}
};